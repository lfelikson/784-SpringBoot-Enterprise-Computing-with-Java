package com.journaldev.bootiful_mongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootifulMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
