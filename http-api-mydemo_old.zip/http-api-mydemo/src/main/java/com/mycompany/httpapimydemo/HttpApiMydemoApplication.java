package com.mycompany.httpapimydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpApiMydemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpApiMydemoApplication.class, args);
	}

}
